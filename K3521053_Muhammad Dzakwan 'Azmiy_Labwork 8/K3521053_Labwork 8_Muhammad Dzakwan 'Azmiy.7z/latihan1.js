$(document).ready(function () {
    $('button').click(function () {
        $('span').toggleClass('active');
    });
});